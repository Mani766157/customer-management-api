
# Customer Management API

## How to Run
```bash
mvn clean install
mvn spring-boot:run
```

## H2 Console
- http://localhost:8080/h2-console
- JDBC URL: jdbc:h2:mem:testdb

## Swagger UI (or) OpenAPI
- http://localhost:8080/swagger-ui.html
- openapi.yaml

## Endpoints
- POST /customers
- GET /customers/{id}
- GET /customers?name={name}
- GET /customers?email={email}
- PUT /customers/{id}
- DELETE /customers/{id}

## Requests and Responses
- Added in Requests and Responses.docx

## Assumptions
- Tier is computed on-the-fly.
- Email is unique.
