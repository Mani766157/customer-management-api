
package com.example.customers;

import static org.junit.jupiter.api.Assertions.*;

import java.time.LocalDateTime;
import java.util.UUID;

import org.junit.jupiter.api.MethodOrderer;
import org.junit.jupiter.api.Order;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestMethodOrder;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.example.customers.dto.CustomerRequest;
import com.example.customers.dto.CustomerResponse;
import com.example.customers.service.CustomerService;

@SpringBootTest
@TestMethodOrder(MethodOrderer.OrderAnnotation.class)
public class CustomerServiceTests {

	@Autowired
	private CustomerService service;

	static UUID testCustomerId;

	@Test
	@Order(1)
	public void testCreateCustomer() {
		CustomerRequest request = new CustomerRequest();
		request.setName("Test User");
		request.setEmail("testuser@example.com");
		request.setAnnualSpend(1200.0);
		request.setLastPurchaseDate(LocalDateTime.now().minusMonths(3));

		CustomerResponse response = service.create(request);
		testCustomerId = response.getId();

		assertNotNull(response.getId());
		assertEquals("Test User", response.getName());
		assertEquals("Gold", response.getTier());
	}

	@Test
	@Order(2)
	public void testRetrieveCustomerById() {
		CustomerResponse response = service.getById(testCustomerId);
		assertEquals("testuser@example.com", response.getEmail());
	}

	@Test
	@Order(3)
	public void testUpdateCustomer() {
		CustomerRequest updatedRequest = new CustomerRequest();
		updatedRequest.setName("Updated User");
		updatedRequest.setEmail("updateduser@example.com");
		updatedRequest.setAnnualSpend(15000.0);
		updatedRequest.setLastPurchaseDate(LocalDateTime.now().minusMonths(5));

		CustomerResponse updatedResponse = service.update(testCustomerId, updatedRequest);
		assertEquals("Updated User", updatedResponse.getName());
		assertEquals("Platinum", updatedResponse.getTier());
	}

	@Test
	@Order(4)
	public void testDeleteCustomer() {
		service.delete(testCustomerId);
		Exception exception = assertThrows(RuntimeException.class, () -> {
			service.getById(testCustomerId);
		});
		assertEquals("Customer not found", exception.getMessage());
	}

	@Test
	public void testTierSilverCalculation() {
		CustomerRequest silver = new CustomerRequest();
		silver.setName("SilverUser");
		silver.setEmail("silver@example.com");
		silver.setAnnualSpend(500.0);
		silver.setLastPurchaseDate(LocalDateTime.now().minusMonths(13));
		assertEquals("Silver", service.create(silver).getTier());
	}

	@Test
	public void testTierGoldCalculation() {
		CustomerRequest gold = new CustomerRequest();
		gold.setName("GoldUser");
		gold.setEmail("gold@example.com");
		gold.setAnnualSpend(2000.0);
		gold.setLastPurchaseDate(LocalDateTime.now().minusMonths(10));
		assertEquals("Gold", service.create(gold).getTier());
	}

	@Test
	public void testTierPlatinumCalculation() {
		CustomerRequest platinum = new CustomerRequest();
		platinum.setName("PlatinumUser");
		platinum.setEmail("platinum@example.com");
		platinum.setAnnualSpend(15000.0);
		platinum.setLastPurchaseDate(LocalDateTime.now().minusMonths(4));
		assertEquals("Platinum", service.create(platinum).getTier());
	}

	@Test
	public void testInvalidEmailFormat() {
		CustomerRequest invalid = new CustomerRequest();
		invalid.setName("Bad Email");
		invalid.setEmail("bad-email-format");
		invalid.setAnnualSpend(1000.0);
		invalid.setLastPurchaseDate(LocalDateTime.now().minusMonths(1));

		Exception exception = assertThrows(Exception.class, () -> {
			service.create(invalid);
		});

		assertTrue(exception.getMessage().toLowerCase().contains("could not execute statement")
				|| exception.getMessage().toLowerCase().contains("constraint")
				|| exception.getMessage().toLowerCase().contains("validation")
				|| exception.getMessage().toLowerCase().contains("email is invalid"));
	}
}
