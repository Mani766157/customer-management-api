
package com.example.customers.service;

import java.time.LocalDateTime;
import java.time.temporal.ChronoUnit;
import java.util.UUID;
import java.util.regex.Pattern;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.customers.dto.CustomerRequest;
import com.example.customers.dto.CustomerResponse;
import com.example.customers.entity.Customer;
import com.example.customers.repository.CustomerRepository;

@Service
public class CustomerService {

	@Autowired
	private CustomerRepository repository;

	public CustomerResponse create(CustomerRequest request) {
    	if(!isValid(request.getEmail()))throw new RuntimeException("Customer Email is invalid");
        Customer customer = new Customer(null, request.getName(), request.getEmail(), request.getAnnualSpend(), request.getLastPurchaseDate());
        return toResponse(repository.save(customer));
    }

	public CustomerResponse getById(UUID id) {
		return repository.findById(id).map(this::toResponse)
				.orElseThrow(() -> new RuntimeException("Customer not found"));
	}

	public CustomerResponse getByEmail(String email) {
		return repository.findByEmail(email).map(this::toResponse)
				.orElseThrow(() -> new RuntimeException("Customer not found"));
	}

	public CustomerResponse getByName(String name) {
		return repository.findByName(name).map(this::toResponse)
				.orElseThrow(() -> new RuntimeException("Customer not found"));
	}

	public CustomerResponse update(UUID id, CustomerRequest request) {
		Customer customer = repository.findById(id).orElseThrow(() -> new RuntimeException("Customer not found"));
		customer.setName(request.getName());
		customer.setEmail(request.getEmail());
		customer.setAnnualSpend(request.getAnnualSpend());
		customer.setLastPurchaseDate(request.getLastPurchaseDate());
		return toResponse(repository.save(customer));
	}

	public void delete(UUID id) {
		repository.deleteById(id);
	}

	private boolean isValid(String email) {
		String pattern = "^[_A-Za-z0-9-+]+(.[_A-Za-z0-9-]+)*@" + "[A-Za-z0-9-]+(.[A-Za-z0-9]+)*(.[A-Za-z]{2,})$";
		return Pattern.compile(pattern).matcher(email).matches();
	}

	private CustomerResponse toResponse(Customer customer) {
		CustomerResponse response = new CustomerResponse();
		response.setId(customer.getId());
		response.setName(customer.getName());
		response.setEmail(customer.getEmail());
		response.setAnnualSpend(customer.getAnnualSpend());
		response.setLastPurchaseDate(customer.getLastPurchaseDate());
		response.setTier(determineTier(customer.getAnnualSpend(), customer.getLastPurchaseDate()));
		return response;
	}

	private String determineTier(Double spend, LocalDateTime lastPurchase) {
		if (spend == null || lastPurchase == null)
			return "Silver";
		long monthsAgo = ChronoUnit.MONTHS.between(lastPurchase, LocalDateTime.now());
		if (spend >= 10000 && monthsAgo <= 6)
			return "Platinum";
		if (spend >= 1000 && spend < 10000 && monthsAgo <= 12)
			return "Gold";
		return "Silver";
	}
}
